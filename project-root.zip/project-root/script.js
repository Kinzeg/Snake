const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');
const scoreCounter = document.getElementById('score-counter');
const levelCounter = document.getElementById('level-counter');
const restartButton = document.getElementById('restart-button');
const foodImage = new Image();
foodImage.src = 'eat.png';

const gridSize = 20;
let snake = [];
let food = { x: 0, y: 0 };
let direction = 'right';
let score = 0;
let level = 1;
let gameSpeed = 150;
let isGameOver = false;
let highScore = 0; 

const imagesPaths = {
    head_up: 'head_up.png',
    head_down: 'head_down.png',
    head_left: 'head_left.png',
    head_right: 'head_right.png',
    body_horizontal: 'body_horizontal.png',
    body_vertical: 'body_vertical.png',
    body_turn_up_left: 'body_bottomright.png',
    body_turn_up_right: 'body_bottomleft.png',
    body_turn_down_left: 'body_topright.png',
    body_turn_down_right: 'body_topleft.png',
    tail_up: 'tail_up.png',
    tail_down: 'tail_down.png',
    tail_left: 'tail_left.png',
    tail_right: 'tail_right.png'
}

const snakeImages = {};

function loadImages() {
    const loadImage = (imageName) => {
        return new Promise(resolve => {
            const image = new Image();
            image.src = imagesPaths[imageName];
            image.onload = () => {
                snakeImages[imageName] = image;
                resolve();
            }
        })
    };

    const imageNames = Object.keys(imagesPaths);
    Promise.all(imageNames.map(loadImage)).then(() => {
        initGame();
    })
}
function getHighScore() {
    return localStorage.getItem('highScore') ? parseInt(localStorage.getItem('highScore')) : 0;
}
function saveHighScore(score) {
    localStorage.setItem('highScore', score);
}

function initGame() {
    snake = [{ x: gridSize * 10, y: gridSize * 10 }, { x: gridSize * 10 - gridSize, y: gridSize * 10 }];
    direction = 'right';
    score = 0;
    level = 1;
    gameSpeed = 150;
    scoreCounter.innerText = score;
    levelCounter.innerText = level;
    isGameOver = false;
    generateFood();

    highScore = getHighScore();

    document.getElementById('high-score-display').innerText = 'Лучший результат: ' + highScore;
    gameLoop();
}

function generateFood() {
    food = {
        x: Math.floor(Math.random() * (canvas.width / gridSize)) * gridSize,
        y: Math.floor(Math.random() * (canvas.height / gridSize)) * gridSize
    };
    for (let i = 0; i < snake.length; i++) {
        if (food.x === snake[i].x && food.y === snake[i].y) {
            generateFood();
            return;
        }
    }
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    snake.forEach((segment, index) => {
        let imageName;
        if (index === 0) {
            switch (direction) {
                case 'up':
                    imageName = 'head_up';
                    break;
                case 'down':
                    imageName = 'head_down';
                    break;
                case 'left':
                    imageName = 'head_left';
                    break;
                case 'right':
                    imageName = 'head_right';
                    break;
            }
        } else if (index === snake.length - 1) {
            const prevSegment = snake[index - 1];
            const currentSegment = segment;
            let dx = currentSegment.x - prevSegment.x;
            let dy = currentSegment.y - prevSegment.y;
            if (dx > 0) {
                imageName = 'tail_right';
            } else if (dx < 0) {
                imageName = 'tail_left';
            }
            else if (dy > 0) {
                imageName = 'tail_down';
            } else if (dy < 0) {
                imageName = 'tail_up';
            }
        } else {
            const prevSegment = snake[index - 1];
            const currentSegment = segment;

            if (index < snake.length - 1) {
                const nextSegment = snake[index + 1];

                let dxPrev = currentSegment.x - prevSegment.x;
                let dyPrev = currentSegment.y - prevSegment.y;
                let dxNext = currentSegment.x - nextSegment.x;
                let dyNext = currentSegment.y - nextSegment.y;

                if (dxPrev !== 0 && dxNext !== 0) {
                    imageName = 'body_horizontal';
                } else if (dyPrev !== 0 && dyNext !== 0) {
                    imageName = 'body_vertical';
                } else if ((dxPrev === -gridSize && dyNext === -gridSize) || (dyPrev === -gridSize && dxNext === -gridSize)) {
                    imageName = 'body_turn_up_left';
                } else if ((dxPrev === gridSize && dyNext === -gridSize) || (dyPrev === -gridSize && dxNext === gridSize)) {
                    imageName = 'body_turn_up_right';
                } else if ((dxPrev === -gridSize && dyNext === gridSize) || (dyPrev === gridSize && dxNext === -gridSize)) {
                    imageName = 'body_turn_down_left';
                } else if ((dxPrev === gridSize && dyNext === gridSize) || (dyPrev === gridSize && dxNext === gridSize)) {
                    imageName = 'body_turn_down_right';
                }
            } else {
                let dx = currentSegment.x - prevSegment.x;
                let dy = currentSegment.y - prevSegment.y;
                if (dx !== 0) {
                    imageName = 'body_horizontal';
                } else {
                    imageName = 'body_vertical';
                }
            }

        }
        if (!imageName) {
            console.log(`Error with imageName. Index: ${index}, direction: ${direction}, segment: ${segment}, length: ${snake.length}`)
        }
        ctx.drawImage(snakeImages[imageName], segment.x, segment.y, gridSize, gridSize);
    });
    drawFood();
}


function drawFood() {
    ctx.drawImage(foodImage, food.x, food.y, gridSize, gridSize);
}

function move() {
    const head = { x: snake[0].x, y: snake[0].y };

    switch (direction) {
        case 'up':
            head.y -= gridSize;
            break;
        case 'down':
            head.y += gridSize;
            break;
        case 'left':
            head.x -= gridSize;
            break;
        case 'right':
            head.x += gridSize;
            break;
    }

    snake.unshift(head);
    const eatenFood = head.x === food.x && head.y === food.y;
    if (eatenFood) {
        score++;
        scoreCounter.innerText = score;
        if (score % 5 === 0) {
            level++;
            levelCounter.innerText = level;
            gameSpeed = gameSpeed > 50 ? gameSpeed - 15 : 50;
        }
        generateFood();
    } else {
        snake.pop();
    }
}

function checkCollision() {
    const head = snake[0];
    if (head.x < 0 || head.x >= canvas.width || head.y < 0 || head.y >= canvas.height) {
        return true;
    }

    for (let i = 1; i < snake.length; i++) {
        if (head.x === snake[i].x && head.y === snake[i].y) {
            return true;
        }
    }

    return false;
}

function gameLoop() {
    if (isGameOver) return;

    if (checkCollision()) {
        isGameOver = true;
        gameOver();
        return;
    }

    move();
    draw();

    setTimeout(gameLoop, gameSpeed);
}

function gameOver() {
    isGameOver = true;

    if (score > highScore) {
        highScore = score;
        saveHighScore(highScore);
        document.getElementById('high-score-display').innerText = 'Новый лучший результат: ' + highScore;
    }

    alert('Игра окончена! Ваш счет: ' + score);
}

document.addEventListener('keydown', (e) => {
    if (isGameOver) return;
    switch (e.key) {
        case 'ArrowUp':
            if (direction !== 'down') direction = 'up';
            break;
        case 'ArrowDown':
            if (direction !== 'up') direction = 'down';
            break;
        case 'ArrowLeft':
            if (direction !== 'right') direction = 'left';
            break;
        case 'ArrowRight':
            if (direction !== 'left') direction = 'right';
            break;
    }
});

restartButton.addEventListener('click', initGame);

loadImages();